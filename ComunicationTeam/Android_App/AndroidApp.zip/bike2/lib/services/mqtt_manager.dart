import 'dart:convert';
import 'dart:io';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MqttManager {
  late MqttServerClient client;

  Future<bool> connect() async {
    final prefs = await SharedPreferences.getInstance();
    final broker = prefs.getString('broker') ?? 'a1ca893b5c4e479db453dd07753646e0.s1.eu.hivemq.cloud';
    final port = int.tryParse(prefs.getString('port') ?? '') ?? 8883;
    final username = prefs.getString('username') ?? '';
    final password = prefs.getString('password') ?? '';
    final topic = prefs.getString('topic') ?? 'bike/light/status';

    client = MqttServerClient.withPort(broker, 'flutter-client', port);
    client.secure = true;
    client.setProtocolV311();
    client.keepAlivePeriod = 20;
    client.logging(on: false);

    client.securityContext = SecurityContext.defaultContext;

    final connMess = MqttConnectMessage()
        .withClientIdentifier('flutter-client')
        .authenticateAs(username, password)
        .startClean();

    client.connectionMessage = connMess;

    try {
      final connResult = await client.connect();
      if (client.connectionStatus!.state == MqttConnectionState.connected) {
        print("✅ Connected to $broker:$port");
        client.subscribe(topic, MqttQos.atMostOnce);
        return true;
      } else {
        print("❌ Connection failed - status: ${client.connectionStatus}");
        client.disconnect();
        return false;
      }
    } catch (e) {
      print('❌ Exception during connect: $e');
      client.disconnect();
      return false;
    }
  }

  void listenToMessages(Function(String) onMessage) {
    client.updates?.listen((List<MqttReceivedMessage<MqttMessage>> messages) {
      final payload =
          (messages[0].payload as MqttPublishMessage).payload.message;
      final message = String.fromCharCodes(payload);
      print("📩 Received message: $message");
      onMessage(message);
    });
  }

  void publish(String message, {String? topicOverride}) async {
    if (client.connectionStatus?.state != MqttConnectionState.connected) {
      print("⚠️ MQTT client is not connected. Cannot publish.");
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    final topic = topicOverride ?? prefs.getString('topic') ?? 'bike/light/status';

    final builder = MqttClientPayloadBuilder();
    builder.addString(message);

    client.publishMessage(topic, MqttQos.atMostOnce, builder.payload!);
    print("🚀 Published '$message' to topic '$topic'");
  }


}



