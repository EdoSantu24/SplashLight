class MqttConfig {
  final String broker;
  final String port;
  final String username;
  final String password;
  final String topic;

  MqttConfig({
    required this.broker,
    required this.port,
    required this.username,
    required this.password,
    required this.topic,
  });

  Map<String, String> toMap() {
    return {
      'broker': broker,
      'port': port,
      'username': username,
      'password': password,
      'topic': topic,
    };
  }

  factory MqttConfig.fromMap(Map<String, String> map) {
    return MqttConfig(
      broker: map['broker'] ?? 'a1ca893b5c4e479db453dd07753646e0.s1.eu.hivemq.cloud',
      port: map['port'] ?? '8883',
      username: map['username'] ?? '',
      password: map['password'] ?? '',
      topic: map['topic'] ?? 'bike/light/status',
    );
  }
}

