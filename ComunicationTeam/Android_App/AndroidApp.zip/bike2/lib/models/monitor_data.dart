class MonitorData {
  static final MonitorData _instance = MonitorData._internal();

  factory MonitorData() {
    return _instance;
  }

  MonitorData._internal();

  String lightStatus = 'Waiting...';
  String source = '';
  String battery = '';
  bool isLedOn = false;

  // ✅ Dati per la ControlPage
  String mode = 'active';
  double? latitude;
  double? longitude;
  DateTime? timestamp;

  void updateData({
    String? lightStatus,
    String? source,
    String? battery,
    bool? isLedOn,
    String? mode,
    double? latitude,
    double? longitude,
    DateTime? timestamp,
  }) {
    if (lightStatus != null) this.lightStatus = lightStatus;
    if (source != null) this.source = source;
    if (battery != null) this.battery = battery;
    if (isLedOn != null) this.isLedOn = isLedOn;

    if (mode != null) this.mode = mode;
    if (latitude != null) this.latitude = latitude;
    if (longitude != null) this.longitude = longitude;
    if (timestamp != null) this.timestamp = timestamp;
  }
}
