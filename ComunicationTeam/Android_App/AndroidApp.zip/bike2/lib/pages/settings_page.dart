import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/mqtt_manager.dart';
import '../models/mqtt_config.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _formKey = GlobalKey<FormState>();
  final _brokerController = TextEditingController();
  final _portController = TextEditingController(text: '8883');
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _topicController = TextEditingController(text: 'bike/light/status');

  String _connectionStatus = '';

  @override
  void initState() {
    super.initState();
    _loadConfig();
  }

  Future<void> _loadConfig() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _brokerController.text = prefs.getString('broker') ?? 'a1ca893b5c4e479db453dd07753646e0.s1.eu.hivemq.cloud';
      _portController.text = prefs.getString('port') ?? '8883';
      _usernameController.text = prefs.getString('username') ?? 'bikeuser';
      _passwordController.text = prefs.getString('password') ?? 'Mybike123';
      _topicController.text = prefs.getString('topic') ?? 'bike/light/status';
    });
  }

  Future<void> _saveConfig() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('broker', _brokerController.text);
    await prefs.setString('port', _portController.text);
    await prefs.setString('username', _usernameController.text);
    await prefs.setString('password', _passwordController.text);
    await prefs.setString('topic', _topicController.text);
  }

  Future<void> _testConnection() async {
    setState(() => _connectionStatus = '🔄 Connecting...');
    final mqttManager = MqttManager();

    final success = await mqttManager.connect();
    setState(() {
      _connectionStatus = success ? '✅ Connected!' : '❌ Connection failed';
    });

    if (success) {
      // Optionally start listening for messages
      mqttManager.listenToMessages((message) {
        print("Received: $message");
        // You could display the message in the UI if needed
      });
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            'Settings',
            style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
          ),
        ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _brokerController,
                decoration: const InputDecoration(labelText: 'Broker Address'),
                validator: (value) => value!.isEmpty ? 'Required' : null,
              ),
              TextFormField(
                controller: _portController,
                decoration: const InputDecoration(labelText: 'Port'),
                keyboardType: TextInputType.number,
              ),
              TextFormField(
                controller: _usernameController,
                decoration: const InputDecoration(labelText: 'Username'),
              ),
              TextFormField(
                controller: _passwordController,
                decoration: const InputDecoration(labelText: 'Password'),
                obscureText: true,
              ),
              TextFormField(
                controller: _topicController,
                decoration: const InputDecoration(labelText: 'Subscribe Topic'),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    await _saveConfig();
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Settings saved')),
                    );
                  }
                },
                child: const Text('💾 Save'),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: _testConnection,
                child: const Text('🔌 Test Connection'),
              ),
              const SizedBox(height: 20),
              Center(child: Text(_connectionStatus)),
            ],
          ),
        ),
      ),
    );
  }
}

