import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import '../services/mqtt_manager.dart';
import '../models/monitor_data.dart';

class MonitorPage extends StatefulWidget {
  const MonitorPage({Key? key}) : super(key: key);

  @override
  State<MonitorPage> createState() => _MonitorPageState();
}

class _MonitorPageState extends State<MonitorPage> {
  final mqttManager = MqttManager();
  final monitorData = MonitorData(); // Singleton

  // Variabili esistenti
  String lightStatus = 'Waiting...';
  String source = '';
  String battery = '';
  bool isLedOn = false;
  bool isConnected = false;

  // Variabili da ControlPage
  LatLng? userLocation;
  bool waitingGpsResponse = false;
  Timer? gpsTimeoutTimer;

  @override
  void initState() {
    super.initState();
    lightStatus = monitorData.lightStatus;
    source = monitorData.source;
    battery = monitorData.battery;
    isLedOn = monitorData.isLedOn;
    _initMqtt();
  }

  void _initMqtt() async {
    final connected = await mqttManager.connect();
    setState(() => isConnected = connected);

    if (connected) {
      print('🔌 MQTT connection established');

      mqttManager.listenToMessages((message) {
        print('📨 Received: $message');

        try {
          final data = jsonDecode(message);

          final newLightStatus = data['led'] ?? monitorData.lightStatus;
          final newSource = data['source'] ?? monitorData.source;
          final newMode = data['mode'] ?? monitorData.mode;
          final newBattery = data['battery']?.toString() ?? monitorData.battery;
          final newIsLedOn = newLightStatus.toLowerCase().contains('on');
          final newLatitude = data['latitude'];
          final newLongitude = data['longitude'];

          monitorData.updateData(
            lightStatus: newLightStatus,
            source: newSource,
            battery: newBattery,
            isLedOn: newIsLedOn,
            latitude: newLatitude,
            longitude: newLongitude,
            timestamp: DateTime.now(),
            mode: newMode,
          );

          setState(() {
            lightStatus = newLightStatus;
            source = newSource;
            battery = newBattery;
            isLedOn = newIsLedOn;

            if (newLatitude != null && newLongitude != null) {
              waitingGpsResponse = false;
              gpsTimeoutTimer?.cancel();
            }
          });
        } catch (_) {
          print('⚠️ Error decoding JSON. Assuming raw LED state.');
          final newLightStatus = message;
          final newIsLedOn = newLightStatus.toLowerCase().contains('on');

          monitorData.updateData(
            lightStatus: newLightStatus,
            isLedOn: newIsLedOn,
          );

          setState(() {
            lightStatus = newLightStatus;
            isLedOn = newIsLedOn;
          });
        }
      });
    } else {
      setState(() => lightStatus = 'Connection failed');
    }
  }

  void toggleLed() {
    final message = isLedOn ? 'off' : 'on';
    mqttManager.publish(message);
    print("🟢 Sending LED command: $message");

    monitorData.updateData(
      lightStatus: message,
      isLedOn: !isLedOn,
    );

    setState(() => isLedOn = !isLedOn);
  }

  void sendMode(String mode) {
    mqttManager.publish(mode);
    monitorData.updateData(mode: mode);
    setState(() {}); // Per riflettere cambiamenti nel UI se necessario
  }

  void requestGps() async {
    mqttManager.publish('gps');
    print("🟢 Requesting GPS from smart light");

    setState(() {
      waitingGpsResponse = true;
    });

    gpsTimeoutTimer?.cancel();
    gpsTimeoutTimer = Timer(const Duration(seconds: 10), () {
      if (waitingGpsResponse) {
        print("🕒 No GPS response received in time.");
        setState(() => waitingGpsResponse = false);
      }
    });

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.always ||
        permission == LocationPermission.whileInUse) {
      Position position = await Geolocator.getCurrentPosition();
      setState(() {
        userLocation = LatLng(position.latitude, position.longitude);
      });
      print("📍 User location obtained: ${position.latitude}, ${position
          .longitude}");
    } else {
      print("📍 GPS permission not granted");
    }
  }

  @override
  Widget build(BuildContext context) {
    final textStyle = Theme
        .of(context)
        .textTheme
        .titleMedium;

    final lightLat = monitorData.latitude;
    final lightLon = monitorData.longitude;
    final lightLocation = (lightLat != null && lightLon != null)
        ? LatLng(lightLat, lightLon)
        : null;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Smart Light',
          style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Row(
              children: [
                Text(
                  isConnected ? 'Online' : 'Offline',
                  style: GoogleFonts.poppins(
                    color: Colors.black,
                    fontWeight: FontWeight.w500,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(width: 6),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isConnected ? Colors.green : Colors.red,
                  ),
                ),
              ],
            ),
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // LED card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    blurRadius: 10,
                    color: Colors.black.withOpacity(0.05),
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                children: [
                  const SizedBox(height: 8),
                  Icon(
                    isLedOn ? Icons.lightbulb : Icons.lightbulb_outline,
                    size: 60,
                    color: isLedOn ? Colors.amber : Colors.grey,
                  ),
                  const SizedBox(height: 12),
                  FlutterSwitch(
                    value: isLedOn,
                    activeColor: Colors.deepPurple,
                    inactiveColor: Colors.grey,
                    toggleColor: Colors.white,
                    borderRadius: 20.0,
                    padding: 8.0,
                    width: 80.0,
                    height: 40.0,
                    showOnOff: true,
                    activeText: "ON",
                    inactiveText: "OFF",
                    activeTextColor: Colors.white,
                    inactiveTextColor: Colors.white,
                    onToggle: (_) => toggleLed(),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'LED Status: ${isLedOn ? "ON" : "OFF"}',
                    style: GoogleFonts.poppins(fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            _buildInfoTile(icon: Icons.power, title: "Source", value: source),
            const SizedBox(height: 16),
            _buildInfoTile(
                icon: Icons.battery_full, title: "Battery", value: '$battery%'),
            const SizedBox(height: 24),

            // Mode card
            _buildCard(
              title: 'Mode',
              child: ToggleButtons(
                borderRadius: BorderRadius.circular(12),
                isSelected: [
                  monitorData.mode == 'active',
                  monitorData.mode == 'parking',
                  monitorData.mode == 'storage',
                ],
                onPressed: (index) {
                  final modes = ['active', 'parking', 'storage'];
                  sendMode(modes[index]);
                },
                children: const [
                  Padding(padding: EdgeInsets.symmetric(horizontal: 16),
                      child: Text('Active')),
                  Padding(padding: EdgeInsets.symmetric(horizontal: 16),
                      child: Text('Parking')),
                  Padding(padding: EdgeInsets.symmetric(horizontal: 16),
                      child: Text('Storage')),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // GPS card
            _buildCard(
              title: 'GPS Location',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                          vertical: 14, horizontal: 24),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                    ),
                    icon: const Icon(Icons.gps_fixed, size: 28),
                    label: const Text(
                        'Request coordinates', style: TextStyle(fontSize: 18)),
                    onPressed: requestGps,
                  ),
                  const SizedBox(height: 16),
                  if (userLocation != null)
                    Text("📍 Phone: ${userLocation!.latitude}, ${userLocation!
                        .longitude}",
                        style: textStyle),
                  if (lightLocation != null)
                    Text(
                      "💡 Light: ${lightLocation.latitude}, ${lightLocation
                          .longitude} "
                          "(${monitorData.timestamp != null
                          ? 'updated at ${monitorData.timestamp!
                          .hour}:${monitorData.timestamp!
                          .minute
                          .toString()
                          .padLeft(2, '0')}'
                          : ''})",
                      style: textStyle,
                    ),
                  const SizedBox(height: 16),
                  SizedBox(
                    height: 300,
                    child: (userLocation != null)
                        ? FlutterMap(
                      options: MapOptions(
                        initialCenter: userLocation!,
                        initialZoom: 14,
                      ),
                      children: [
                        TileLayer(
                          urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                          userAgentPackageName: 'com.example.app',
                        ),
                        MarkerLayer(
                          markers: [
                            Marker(
                              point: userLocation!,
                              width: 40,
                              height: 40,
                              child: const Icon(Icons.person_pin_circle,
                                  color: Colors.blue, size: 36),
                            ),
                            if (lightLocation != null)
                              Marker(
                                point: lightLocation,
                                width: 40,
                                height: 40,
                                child: const Icon(Icons.lightbulb,
                                    color: Colors.orange, size: 36),
                              ),
                          ],
                        ),
                      ],
                    )
                        : Center(
                      child: Text(
                          'Waiting for phone location...', style: textStyle),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoTile({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            blurRadius: 8,
            color: Colors.black.withOpacity(0.04),
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(icon, size: 28, color: Colors.deepPurple),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              title,
              style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w500),
            ),
          ),
          Text(
            value,
            style: GoogleFonts.poppins(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCard({required String title, required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            blurRadius: 10,
            color: Colors.black.withOpacity(0.05),
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.poppins(
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

}
